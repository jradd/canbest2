module.exports.currentYear = function () { 
  d = new Date();
  return d.getFullYear();
};